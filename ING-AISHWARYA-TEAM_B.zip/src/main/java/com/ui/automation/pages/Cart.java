package com.ui.automation.pages;

public class Cart {

	public Cart() {
		// TODO Auto-generated constructor stub
	}

}
