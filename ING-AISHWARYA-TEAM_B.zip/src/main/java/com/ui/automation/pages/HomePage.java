package com.ui.automation.pages;

public class HomePage {

	public HomePage() {
		// TODO Auto-generated constructor stub
	}

}
