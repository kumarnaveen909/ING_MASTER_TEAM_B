package com.ui.automation.pages;

public class HealthAndSafety {

	public HealthAndSafety() {
		// TODO Auto-generated constructor stub
	}

}
